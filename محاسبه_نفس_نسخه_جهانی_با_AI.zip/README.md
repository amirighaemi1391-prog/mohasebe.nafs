# محاسبه نفس — Android

این پروژه نسخه وب «محاسبه نفس» را داخل یک اپ اندروید قرار می‌دهد.

## ساخت APK
1. Android Studio را نصب کنید.
2. این پوشه را با Open باز کنید.
3. Gradle Sync را انجام دهید.
4. از منوی Build گزینه Build APK(s) را انتخاب کنید.
5. APK در مسیر `app/build/outputs/apk/debug/app-debug.apk` ساخته می‌شود.

نیازمندی: Android SDK با API 35 و Android Gradle Plugin 8.7.3.

این برنامه فعلاً بدون سرور کار می‌کند و اطلاعات انتخاب‌ها را در LocalStorage همان WebView ذخیره می‌کند.
