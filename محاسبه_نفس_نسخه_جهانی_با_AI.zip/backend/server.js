// نمونه سرور امن برای راهنمای هوشمند.
// کلید API را هرگز داخل APK قرار ندهید؛ آن را فقط روی سرور در متغیر محیطی نگه دارید.
import express from 'express';
import OpenAI from 'openai';
const app=express(); app.use(express.json({limit:'64kb'}));
const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
app.post('/api/guide', async (req,res)=>{
  try{
    const q=String(req.body?.question||'').slice(0,4000);
    if(!q) return res.status(400).json({error:'question_required'});
    const response=await client.responses.create({
      model:process.env.OPENAI_MODEL||'gpt-5',
      input:[{role:'system',content:[{type:'input_text',text:'You are a careful multilingual research assistant for a global faith and knowledge app. Distinguish primary text, scholarly interpretation, AI synthesis, and uncertainty. Never invent quotations or references. For Islamic questions, respect differences between schools and ask for the user’s tradition when it materially affects the answer. Do not issue fatwas. For scientific claims, prefer evidence and identify the quality of evidence.'}]},{role:'user',content:[{type:'input_text',text:q}]}]
    });
    res.json({answer:response.output_text||'No answer generated.'});
  }catch(e){res.status(500).json({error:'ai_request_failed'});}
});
app.listen(process.env.PORT||8787);
